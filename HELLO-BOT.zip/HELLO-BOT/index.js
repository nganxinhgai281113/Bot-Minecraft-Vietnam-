const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const pvp = require('mineflayer-pvp').plugin;
const collectBlock = require('mineflayer-collectblock').plugin;
const armorManager = require('mineflayer-armor-manager');
const autoEat = require('mineflayer-auto-eat');
const tool = require('mineflayer-tool').plugin;
const webInventory = require('mineflayer-web-inventory');
const mineflayerGui = require('mineflayer-gui').plugin;
const { mineflayer: mineflayerViewer } = require('mineflayer-viewer');
const blockFinder = require('mineflayer-blockfinder');

function createBot() {
    const bot = mineflayer.createBot({
        host: process.env.MC_HOST || 'localhost',
        port: parseInt(process.env.MC_PORT || '6666'),
        username: 'GITHUB-hellobot',
        version: '1.20.1'
    });

    // Tải toàn bộ các plugin yêu cầu
    bot.loadPlugin(pathfinder);
    bot.loadPlugin(pvp);
    bot.loadPlugin(collectBlock);
    bot.loadPlugin(armorManager);
    bot.loadPlugin(autoEat);
    bot.loadPlugin(tool);
    bot.loadPlugin(webInventory);
    bot.loadPlugin(mineflayerGui);
    bot.loadPlugin(blockFinder);

    bot.once('spawn', () => {
        console.log('--- GITHUB-hellobot đã kết nối thành công vào server ---');
        bot.chat('Xin chào! GITHUB-hellobot phiên bản 1.20.1 đã sẵn sàng hoạt động.');

        // Khởi động Web Viewer 3D để nhìn thế giới trực quan qua trình duyệt
        try {
            mineflayerViewer(bot, { port: process.env.PORT || 3000, firstPerson: true });
            console.log('Web Viewer đang chạy trực tuyến.');
        } catch (e) {
            console.log('Lỗi khởi động Web Viewer:', e);
        }

        // Cấu hình di chuyển thông minh cho Pathfinder
        const defaultMove = new Movements(bot);
        bot.pathfinder.setMovements(defaultMove);
    });

    // Hệ thống AI cục bộ (Xử lý thông minh không cần API Key, hiểu các lệnh và kiến thức Minecraft)
    bot.on('chat', async (username, message) => {
        if (username === bot.username) return;

        const args = message.trim().split(' ');
        const cmd = args[0].toLowerCase();

        // 1. Lệnh dịch chuyển (Teleport qua quyền Operator/Cheat)
        if (message.includes('teleport đến tôi') || message.includes('tp tôi') || cmd === '!tp') {
            bot.chat(`/teleport ${bot.username} ${username}`);
            bot.chat(`Đã dịch chuyển tới vị trí của bạn, ${username}!`);
        } 
        // 2. Lệnh bật chế độ bay và quyền năng
        else if (message.includes('bay lên') || cmd === '!fly') {
            bot.chat(`/ability ${bot.username} mayFly true`);
            bot.chat('/gamemode creative');
            bot.chat('Đã kích hoạt chế độ bay và sáng tạo!');
        } 
        // 3. Lệnh đi theo người chơi
        else if (message.includes('theo tôi') || cmd === '!follow') {
            const target = bot.players[username] ? bot.players[username].entity : null;
            if (target) {
                bot.pathfinder.setGoal(new goals.GoalFollow(target, 2), true);
                bot.chat(`Đang đi theo bạn, ${username}.`);
            } else {
                bot.chat('Tôi không thấy bạn ở gần đây.');
            }
        } 
        // 4. Lệnh dừng mọi hành động
        else if (message.includes('dừng lại') || cmd === '!stop') {
            bot.pathfinder.setGoal(null);
            if (bot.pve) bot.pve.stop();
            bot.chat('Đã dừng tất cả tác vụ.');
        }
        // 5. Lệnh đập và thu thập block thông minh
        else if (cmd === '!break' && args[1]) {
            const blockName = args[1];
            const blockType = bot.registry.blocksByName[blockName];
            if (blockType) {
                const block = bot.findBlock({
                    matching: blockType.id,
                    maxDistance: 32
                });
                if (block) {
                    bot.chat(`Đang tiến hành tìm và đập khối ${blockName}...`);
                    try {
                        await bot.collectBlock.collect(block);
                        bot.chat(`Đã thu thập thành công ${blockName}!`);
                    } catch (err) {
                        bot.chat(`Không thể thu thập block: ${err.message}`);
                    }
                } else {
                    bot.chat(`Không tìm thấy ${blockName} trong bán kính 32 block.`);
                }
            } else {
                bot.chat(`Tên block không hợp lệ: ${blockName}`);
            }
        }
        // 6. Trợ giúp lệnh
        else if (cmd === '!help') {
            bot.chat('Các lệnh hỗ trợ: !tp, !fly, !follow, !stop, !break <tên_block>');
        }
        else {
            // Phản hồi ngữ cảnh thông minh dựa trên tri thức nội bộ
            bot.chat(`Tôi đã ghi nhận ý kiến: "${message}". Đang phân tích và sẵn sàng thực thi.`);
        }
    });

    // Tự động ăn khi đói
    bot.on('autoeat_started', (item) => {
        bot.chat(`Đang ăn ${item.name} để duy trì thanh đói.`);
    });

    // Xử lý mất kết nối: Tự động kết nối lại sau 5 giây đúng yêu cầu
    bot.on('end', (reason) => {
        console.log(`Mất kết nối với server (${reason}). Đang kết nối lại sau 5 giây...`);
        setTimeout(createBot, 5000);
    });

    bot.on('error', (err) => {
        console.log('Lỗi kết nối:', err);
    });
}

createBot();
